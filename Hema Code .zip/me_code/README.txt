# Ship Database Schema has been created 
# Should be able to view 2 table one for ship id and another for ship txn details
# Ship_Statistic.py = contains the database schema creation 
# ship_app.py = contains the flask UI rest api intergration 
# test_ship_statistic.py = working on testing component 
# show_table() code would able to view the list of insert data into database
# able to view .html file via flask
# able to navigate @app.route('/api/ships') and rendered data 
others wip 